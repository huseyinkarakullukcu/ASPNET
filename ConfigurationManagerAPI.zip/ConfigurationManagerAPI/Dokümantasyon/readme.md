1- Uygulama Visual Studio 2022 ile geliştirilmiştir.
2- Asp .Net Core 8 Web API ve Sawagger kullanılarak geliştirildi.
3- Proje ile ilgili bilgiler dokümantasyon dosyasında bulunmaktadır.
